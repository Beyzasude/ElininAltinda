//
//  ViewController.swift
//  SqliteDemo
//
//  Created by Beyza Erol on 13.11.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblKey: UITextField!
    @IBOutlet weak var lblValue: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        //DbUtil.sharedInstance.addDatabase(key: "bil359", value: "Hello World from database")

    }
    @IBAction func btnGetValue(_ sender: Any) {
        //var keyy = "(key) ('"+lblKey.text!+")"
        
        var keyy = lblKey.text!
        var row = DbUtil.sharedInstance.getByKey(key: keyy)
        lblValue.text = try! row!.get(DbUtil.sharedInstance.Value)
        
    }
}
