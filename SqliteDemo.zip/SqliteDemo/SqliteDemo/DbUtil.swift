//
//  DbUtil.swift
//  SqliteDemo
//
//  Created by Beyza Erol on 13.11.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import Foundation
import SQLite
class DbUtil{
    static var sharedInstance=DbUtil()
    var db: Connection?
    
    let ders_odev = Table("ders_odev")
    let Key = Expression<String>("Key")
    let Value = Expression<String>("Value")
    
    init(){
        let path=NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        print(path)
        
        do{
            db = try Connection("\(path)/Ders_odev.sqlite3")
          /*
            try db!.run(ders_odev.create(block:{
                t in
                t.column(Key)
                t.column(Value)
                
            }))
          */
            
            
            try db!.run(ders_odev.create(temporary: false, ifNotExists: true, block: {
                t in
                t.column(Key, primaryKey: true)
                t.column(Value)
            }))
        }
        catch{
            print("HATA \(error)")
        }
    }
    
    func addDatabase(key :String ,value :String){
        do{
            try db!.run(ders_odev.insert(Key<-key ,Value<-value))
        }
        catch{
            
        }
    }
    
    func getByKey(key:String) -> Row? {
        do{
            let query = ders_odev.filter(Key == key)
            print(query.asSQL())
            var data = try db!.pluck(query)
            return data
        }
        catch{
            print("get by key Error : \(error)")
            return nil
        }
    
    }
}
