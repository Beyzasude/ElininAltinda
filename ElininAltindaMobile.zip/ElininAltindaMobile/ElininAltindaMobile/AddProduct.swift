//
//  AddProduct.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 3.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import SwiftUI

struct AddProduct: View {
    @State private var name:String = ""
    @State private var price:String = ""
    @State private var rating:String = ""
    @State private var stock:String = ""
    @State private var info:String = ""
    @State private var details:String = ""

       @Environment(\.presentationMode) var mode: Binding<PresentationMode>
       
       var body: some View {
           VStack{
               TextField("Enter name", text: $name)
                   .padding(10)
                   .background(Color(.systemGray6))
                   .cornerRadius(5)
                   .disableAutocorrection(true)
                
               TextField("Enter price", text: $price)
                    .padding(10)
                    .background(Color(.systemGray6))
                    .cornerRadius(5)
                    .disableAutocorrection(true)
               // create email field
               TextField("Enter rating", text: $rating)
                   .padding(10)
                   .background(Color(.systemGray6))
                   .cornerRadius(5)
                   .keyboardType(.emailAddress)
                   .autocapitalization(.none)
                   .disableAutocorrection(true)
                
               // create age field, number pad
               TextField("Enter stock", text: $stock)
                   .padding(10)
                   .background(Color(.systemGray6))
                   .cornerRadius(5)
                   .disableAutocorrection(true)
                
              TextField("Enter info", text: $info)
                    .padding(10)
                    .background(Color(.systemGray6))
                    .cornerRadius(5)
                    .disableAutocorrection(true)
            
             TextField("Enter detail", text: $details)
                    .padding(10)
                    .background(Color(.systemGray6))
                    .cornerRadius(5)
                    .disableAutocorrection(true)
            
               // button to add a user
               Button(action: {
                   // call function to add row in sqlite database
                DB_Manager().addProduct(nameValue: self.name, PriceValue: Int64(self.price) ?? 0 , stockValue: Int64(self.stock) ?? 0, ratingValue: Int64(self.rating) ?? 0, infoValue: self.info, detailValue: self.details)
                    
                   // go back to home page
                   self.mode.wrappedValue.dismiss()
               }, label: {
                   Text("Add Product")
               })
                   .frame(maxWidth: .infinity, alignment: .trailing)
                   .padding(.top, 10)
                   .padding(.bottom, 10)
           }.padding()
       }
}

struct AddProduct_Previews: PreviewProvider {
    static var previews: some View {
        AddProduct()
    }
}
