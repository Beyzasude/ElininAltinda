//
//  ContentView.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 3.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reser



import SwiftUI

struct ContentView: View {
    @State var userid : Int64 = 0
    var body: some View {
        NavigationView{
            VStack{
                AppBarView()
                SearchView()
                ProdeuctView(userId: self.userid)
                HStack{
                    if userid == 0{
                        BottomNavbarItem(image: Image("home"))
                        BottomNavbarItem(image: Image("category"))
                        BottomNavbarItem(image: Image("love"))
                        BottomNavbarItem(image: Image("cart"))
                        BottomNavbarItem(image: Image("help"))
                    }
                    else{
                        BottomNavbarHome(userId: self.userid, image: Image("home"))
                         BottomNavbarCategory(image: Image("category"))
                        BottomNavbarFavorites(userId: self.userid ,image: Image("love"))
                        BottomNavbarCart(userId: self.userid,image: Image("cart"))
                        BottomNavbarHelp(image: Image("help"))
                    }
                        
                }
                .padding()
                .background(Color.white)
                .clipShape(Capsule())
                .padding(.horizontal)
                .shadow(color: Color.black.opacity(0.15), radius: 8, x: 2, y: 6)
                .frame( maxHeight: .infinity, alignment: .bottom)
                    
            }
        }
    }
}
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
    
    
    struct AppBarView: View {
        var body: some View {
            HStack{
                NavigationLink(destination: Login(),label: {
                    Image("logo3")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .padding()
                        .background(Color(.white))
                        .cornerRadius(10.0)
                    
                })
                Spacer()
                Text("Elinin Altında")
                    .padding()
                    .foregroundColor(.blue)
                    .font(.title)
            }
        }
    }
    
    
    struct SearchView: View {
        @State private var search:String = ""
        var body: some View {
            HStack{
                Image("search")
                    .resizable()
                    .frame(width: 25 , height: 25)
                    .padding(.trailing,8)
                TextField("Ara", text: $search)
            }
                //.textFieldStyle(RoundedBorderTextFieldStyle())
                //.foregroundColor(.blue)
                .padding()
                .background(Capsule().stroke(Color.blue,lineWidth: 2))
                .cornerRadius(1.0)
                .padding(.horizontal)
            
        }
    }
    
   struct ProdeuctView: View {
    @State var userId : Int64 = 0
    @State var productModels: [ProductModel] = []
    var body: some View {
        VStack {
            ForEach(self.productModels){ (model) in
                NavigationLink(destination: ProductInfo(item: model ,userID: self.userId ), label: {
                    VStack{
                        
                        HStack{
                          
                            Image("logo4")
                                .resizable()
                                .frame(width: 80,height: 80, alignment: .leading)
                                .padding(.horizontal)
                                .background(Color.white)
 
                            VStack{
                                HStack{
                                    Text("Ürün Adı:")
                                    Text(model.name)
                                }
                                .foregroundColor(.white)
                                HStack{
                                    Text("Ürün Bilgisi:")
                                    Text(model.info)
                                }
                                .foregroundColor(.white )
                            }
                        }
                       
                        HStack{
                            Spacer()
                            Text("\(model.price)TL")
                                .padding(.horizontal)
                                .foregroundColor(.white)
                                .background(Rectangle().stroke(Color.white,lineWidth: 1))
                                .frame(width: 100, height: 25, alignment: .bottom)
                            }
                        }
                        .padding()
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                        .frame( maxWidth: .infinity,maxHeight: .infinity)
                })

            }
        }.padding()
                          
        .onAppear(perform: {
            self.productModels = DB_Manager.sharedInstance.getProducts()
        })
    }
}



struct BottomNavbarItem: View {
    @State var isActive : Bool = false
    let image: Image
    var body: some View {
        NavigationLink(destination : Login() , isActive: $isActive){
            Button(action: {
                self.isActive = true
            }, label: {
                image
                .resizable()
                .frame(width: 30, height: 30)
                .frame(maxWidth: .infinity)
            })
            
        }
        
    }
    
}

struct BottomNavbarHome: View {
    @State var isActive : Bool = false
    @State var userId : Int64 = 0
    let image: Image
    var body: some View {
        NavigationLink(destination : ContentView(userid: userId ) ,isActive: $isActive){
            Button(action: {
                self.isActive = true
            }, label: {
                image
                .resizable()
                .frame(width: 30, height: 30)
                .frame(maxWidth: .infinity)
            })
            
        }
        
    }
    
}

struct BottomNavbarFavorites: View {
    @State var isActive : Bool = false
    @State var userId : Int64 = 0
    let image: Image
    var body: some View {
        NavigationLink(destination : MyFavorites(userid: userId ) ,isActive: $isActive){
            Button(action: {
                self.isActive = true
            }, label: {
                image
                .resizable()
                .frame(width: 30, height: 30)
                .frame(maxWidth: .infinity)
            })
            
        }
        
    }
}


struct BottomNavbarCategory: View {
    @State var isActive : Bool = false
    @State var userId : Int64 = 0
    let image: Image
    var body: some View {
        Button(action: {
            self.isActive = true
        }, label: {
            image
            .resizable()
            .frame(width: 30, height: 30)
            .frame(maxWidth: .infinity)
        })
    }
}

struct BottomNavbarCart: View {
    @State var isActive : Bool = false
    @State var userId : Int64 = 0
    let image: Image
    var body: some View {
        NavigationLink(destination : MyCart(userid: userId ) ,isActive: $isActive){
            Button(action: {
                self.isActive = true
            }, label: {
                image
                .resizable()
                .frame(width: 30, height: 30)
                .frame(maxWidth: .infinity)
            })
            
        }
    }
}


struct BottomNavbarHelp: View {
    @State var isActive : Bool = false
    @State var userId : Int64 = 0
    let image: Image
    var body: some View {
        Button(action: {
            self.isActive = true
        }, label: {
            image
            .resizable()
            .frame(width: 30, height: 30)
            .frame(maxWidth: .infinity)
        })
    }
}
