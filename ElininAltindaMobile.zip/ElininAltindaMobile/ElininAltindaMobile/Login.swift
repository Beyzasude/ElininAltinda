//
//  Login.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 3.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import SwiftUI

struct Login: View {
    @State private var email:String = ""
    @State private var password:String = ""
    @State var UserID : Int64 = 0
    @State var flag : Int64 = 0
    @State var flag2 : Int64 = 0
    @State var isActive : Bool = false
    @State var hidden : Bool = false
    
    var body: some View {
        VStack{
            Image("logo")
                .resizable()
                .frame(width: 200 , height: 200)
                .padding()
                    
            VStack(alignment: .leading, spacing: 8, content:{
                Text("GİRİŞ")
                    .padding()
                    .font(.title)
                VStack(alignment: .leading, spacing: 8, content:{
                    Text("e-posta")
                        .fontWeight(.bold)
                        .padding()
                        .foregroundColor(.blue)
                                
                    TextField("örnek@email.com", text: $email)
                        .font(.system(size:20 , weight: .semibold))
                        //.foregroundColor(Color("dark"))
                        .background(Color(.white))
                        .cornerRadius(5)
                        .padding(.horizontal)
                        .padding(.top,5)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                               
                    Divider()
                             
                })
                VStack(alignment: .leading, spacing: 8, content:{
                    Text("şifre")
                        .fontWeight(.bold)
                        .padding()
                        .foregroundColor(.blue)
                    
                    HStack{
                        if self.hidden == false {
                             SecureField("........", text: $password)
                                .font(.system(size:30 , weight: .semibold))
                                //.foregroundColor(Color("dark"))
                                .background(Color(.white))
                                .padding(.horizontal)
                                .padding(.top,5)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                        }
                        else{
                             TextField("........", text: $password)
                                .font(.system(size:20 , weight: .semibold))
                                //.foregroundColor(Color("dark"))
                                .background(Color(.white))
                                .padding(.horizontal)
                                .padding(.top,5)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                        }
                        
                        Button(action: {
                            self.hidden = true
                        }, label: {
                             Image("hidden")
                                .resizable()
                                .frame(width: 30, height: 25)
                                .padding()
                        })
                       
                    }
                    Divider()
                                            
                })
                .padding(.top,5)
                
                NavigationLink(destination: ContentView(userid: self.UserID),isActive: $isActive){
                    
                    Button(action: {
                        self.UserID = DB_Manager.sharedInstance.loginAuthentication(email: self.email, password: self.password)
                        if self.UserID != 0{
                            self.isActive=true
                        }
                            
                        if self.email == "" || self.password == ""{
                            self.flag2 = self.flag2 + 1
                        }
                        else if self.UserID == 0{
                            self.flag=self.flag+1
                        }
                        
                     }, label:{
                        Text("Giriş")
                            .bold()
                            .frame(width: 250,height: 50 , alignment: .center)
                            .foregroundColor(.white)
                            .background(Color.blue)
                            .cornerRadius(10)
                            .padding()
                    }).padding(.leading,CGFloat(60))
                }
                if self.flag != 0 {
                    NavigationLink(destination: Login(), label: {
                         Text("Yanlış E-posta veya Şifre")
                            .foregroundColor(Color.red)
                    })
                    
                }
                if self.flag2 != 0 {
                     NavigationLink(destination: Login(), label: {
                        Text("E-posta veya Şifre Boş bırakılamaz")
                        .foregroundColor(Color.red)
                    })
                }
                Spacer()
                         
                VStack{
                    HStack{
                        Button(action: {}, label: {
                            Text("Şifremi Unuttum?")
                                .foregroundColor(.gray)
                                .padding()
                        })
                        Spacer()
                        
                        NavigationLink(destination: SignUp(), label: {
                            Text("Kayıt Ol")
                            .foregroundColor(.blue)
                            .padding()
                            
                        })
                    }
                }
                         
            })
        }
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
    }
}
