//
//  MyCart.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 6.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import SwiftUI

struct MyCart: View {
     @State var userid : Int64 = 0
    var body: some View {
        NavigationView{
            VStack{
                Text("Sepetinizde \(DB_Manager.sharedInstance.ProductCountCart(userId: self.userid)) tane ürün bulunmaktadır")
                    .padding()
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .padding(.horizontal)
                    .frame( maxWidth: .infinity,maxHeight: .infinity)
                    
                   ProductView(userId: self.userid)
               
                
            }
        }
        .navigationBarBackButtonHidden(true)
        //.navigationBarTitle("Sepetim")
    }
}

struct MyCart_Previews: PreviewProvider {
    static var previews: some View {
        MyCart(userid: Int64())
    }
}

   struct ProductView: View {
    @State var userId : Int64 = 0
    @State var countproduct : Int64 = 0
    @State var productModels: [ProductModel] = []
    var body: some View {
        VStack {
            ForEach(self.productModels){ (model) in
                NavigationLink(destination: ProductInfo(item: model), label: {
                    VStack{
                        HStack{
                            Image("logo2")
                                .resizable()
                                .frame(width: 80,height: 80, alignment: .leading)
                                .padding(.horizontal)
                            VStack{
                                HStack{
                                    Text("Ürün Adı:")
                                    Text(model.name)
                                }
                                .foregroundColor(.white)
                                HStack{
                                    Text("Ürün Bilgisi:")
                                    Text(model.info)
                                }
                                .foregroundColor(.white )
                                
                                HStack{
                                    
                                    Button(action: {
                                        DB_Manager.sharedInstance.DeleteCart(userId: self.userId, productId: model.id)
                                    }, label: {
                                        Text("-")
                                            .foregroundColor(Color.white)
                                            .bold()
                                            .padding()
                                    })
                                    
                                    Text("\(self.countproduct)")
                                        .foregroundColor(Color.white)
                                        .bold()
                                        .padding()
                                    
                                    Button(action: {
                                        DB_Manager.sharedInstance.AddCart(userId: self.userId, productId: model.id)
                                        self.countproduct = self.countproduct + 1
                                    }, label: {
                                        Text("+")
                                            .foregroundColor(Color.white)
                                            .bold()
                                        .padding()
                                    })
                                }
                            }
                        }
                        HStack{
                            Spacer()
                            Text("\(model.price)TL")
                                .padding(.horizontal)
                                .foregroundColor(.white)
                                .background(Rectangle().stroke(Color.white,lineWidth: 1))
                                .frame(width: 100, height: 25, alignment: .bottom)
                            }
                        }
                        .padding()
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                        .frame( maxWidth: .infinity,maxHeight: .infinity)
                })

            }
            
            NavigationLink(destination: ContentView(userid: self.userId), label: {
                 Text("Alışverişe Devam Et")
                    .foregroundColor(Color.black)
                    .padding(.horizontal)
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .padding(.horizontal)
                    .frame( maxWidth: .infinity,maxHeight: .infinity)
            })
            
            HStack{
                VStack{
                    Image("logo2")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .background(Color.white)
                    Text("Sepetteki Ürüne")
                    Text("Benzer Ürünler")
                    
                }
                .background(Color.blue)
                .clipShape(RoundedRectangle(cornerRadius: 25.0))
                .padding(.horizontal)
                .frame( maxWidth: .infinity,maxHeight: .infinity)   .padding(.horizontal)
                
                VStack{
                    Image("logo2")
                        .resizable()
                        .frame(width: 35, height: 35)
                   Text("Sepetteki Ürüne")
                   Text("Benzer Ürünler")
                    
                }
                .background(Color.blue)
                .clipShape(RoundedRectangle(cornerRadius: 25.0))
                .padding(.horizontal)
                .frame( maxWidth: .infinity,maxHeight: .infinity)   .padding(.horizontal)
                
            }
            
            HStack{
                VStack{
                    Text("Toplam")
                    Text("\(DB_Manager.sharedInstance.TotalPrice(userId: self.userId))")
                }
                Text("Ödeneme işlemine geç")
            }
            .background(Color.blue)
            .clipShape(RoundedRectangle(cornerRadius: 25.0))
            .padding(.horizontal)
            .frame( maxWidth: .infinity,maxHeight: .infinity)
            .padding(.horizontal)
            
            HStack{
                BottomNavbarHome(userId: self.userId, image: Image("home"))
                BottomNavbarCategory(image: Image("category"))
                BottomNavbarFavorites(userId: self.userId ,image: Image("love"))
                BottomNavbarCart(userId: self.userId,image: Image("cart"))
                BottomNavbarHelp(image: Image("help"))
            }
            
           
        }.padding()
                          
        .onAppear(perform: {
            self.productModels = DB_Manager.sharedInstance.getCartProducts(userid: self.userId)
        })
        
    }
}
