//
//  MyFavorites.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 5.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import SwiftUI

struct MyFavorites: View {
    @State var userid : Int64 = 0
        var body: some View {
              NavigationView{
                VStack{
                    FavoriteSearchView()
                    FavoriteProdeuctView(userid: self.userid)
                                                        
                   
                      HStack{
                          FavoriteBottomNavbarItem(image: Image("home")){}
                          FavoriteBottomNavbarItem(image: Image("category")){}
                          FavoriteBottomNavbarItem(image: Image("love")){}
                          FavoriteBottomNavbarItem(image: Image("cart")){}
                          FavoriteBottomNavbarItem(image: Image("help")){}
                                  
                      }
                      .padding()
                      .background(Color.white)
                      .clipShape(Capsule())
                      .padding(.horizontal)
                      .shadow(color: Color.black.opacity(0.15), radius: 8, x: 2, y: 6)
                      .frame( maxHeight: .infinity, alignment: .bottom)
                          
              }
            }.navigationBarHidden(true)
    }
}

struct MyFavorites_Previews: PreviewProvider {
    static var previews: some View {
        MyFavorites(userid: Int64())
    }
}

struct FavoriteSearchView: View {
      @State private var search:String = ""
    var body: some View {
        HStack{
            Image("search")
                .resizable()
                .frame(width: 25 , height: 25)
                .padding(.trailing,8)
            TextField("Ara", text: $search)
        }
        //.textFieldStyle(RoundedBorderTextFieldStyle())
        //.foregroundColor(.blue)
        .padding()
        .background(Capsule().stroke(Color.blue,lineWidth: 2))
        .cornerRadius(1.0)
        .padding(.horizontal)
        
    }
}

struct FavoriteProdeuctView: View {
    @State var userid : Int64 = 0
    @State var productModels: [ProductModel] = []
    var body: some View {
    
        VStack {
            ForEach(self.productModels){ (model) in
                NavigationLink(destination: ProductInfo(item: model, userID: self.userid), label: {
                    VStack{
                        HStack{
                            Image("logo2")
                                .resizable()
                                .frame(width: 80,height: 80, alignment: .leading)
                                .padding(.horizontal)
                            VStack{
                                HStack{
                                    Text("Ürün Adı:")
                                    Text(model.name)
                                }
                                .foregroundColor(.white)
                                HStack{
                                    Text("Ürün Bilgisi:")
                                    Text(model.info)
                                }
                                .foregroundColor(.white )
                            }
                        }
                        HStack{
                            Spacer()
                            Text("\(model.price)TL")
                                .padding(.horizontal)
                                .foregroundColor(.white)
                                .background(Rectangle().stroke(Color.white,lineWidth: 1))
                                .frame(width: 100, height: 25, alignment: .bottom)
                            }
                        }
                        .padding()
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                        .frame( maxWidth: .infinity,maxHeight: .infinity)
                })

            }
        }.padding()
        
        .onAppear(perform: {
            self.productModels = DB_Manager.sharedInstance.getFavorites(userid: self.userid)
        })
        
    //.navigationBarHidden(true)
    }
}



struct FavoriteBottomNavbarItem: View {
    let image: Image
    let action: () -> Void
    var body: some View {
        Button(action: action, label: {
            image
            .resizable()
            .frame(width: 30, height: 30)
            .frame(maxWidth: .infinity)
        })
    }
    
}
