//
//  SignUp.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 3.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import SwiftUI

struct SignUp: View {
    @State private var name:String = ""
    @State private var surname:String = ""
    @State private var email:String = ""
    @State private var password:String = ""
    @State var isActive : Bool = false
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    
    var body: some View {
       VStack(alignment: .leading, spacing: 8, content:{
        
        Text("KAYIT OL")
            .font(.title)
        
        VStack(alignment: .leading, spacing: 8, content:{
            Text("Ad")
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.blue)
            TextField("Adınız", text: $name)
                .padding(10)
                .background(Color(.white))
                .cornerRadius(5)
                .disableAutocorrection(true)
        })
        
        VStack(alignment: .leading, spacing: 8, content:{
            Text("Soyad")
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.blue)
            TextField("Soyadınız", text: $surname)
                .padding(10)
                .background(Color(.white))
                .cornerRadius(5)
                .disableAutocorrection(true)
        })
        
       VStack(alignment: .leading, spacing: 8, content:{
             Text("E-Posta")
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.blue)
            TextField("E-posta Adresiniz", text: $email)
                .padding(10)
                .background(Color(.white))
                .cornerRadius(5)
                .keyboardType(.emailAddress)
                .autocapitalization(.none)
                .disableAutocorrection(true)
            
        })
       
        VStack(alignment: .leading, spacing: 8, content:{
             Text("Şifre")
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.blue)
            
            SecureField("Şifreniz", text: $password)
                .padding(10)
                .background(Color(.white))
                .cornerRadius(5)
                .disableAutocorrection(true)
            
        })
       
        
        Button(action: {
        // call function to add row in sqlite database
            DB_Manager().addUser(nameValue: self.name, surnameValue: self.surname, emailValue: self.email, passwordValue: self.password)
                        
            // go back to home page
            self.mode.wrappedValue.dismiss()
            }, label: {
                Text("Devam Et")
                .bold()
                .frame(width: 250,height: 50 , alignment: .center)
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(10)
                .padding()
                
        })
        .frame(maxWidth: .infinity, alignment: .center)
        .padding(.top, 10)
        .padding(.bottom, 10)
        
        Spacer()
        
          HStack(alignment: .center, spacing: 60, content:{
                Text("Zaten bir hesabınız var mı?")
                    .foregroundColor(.gray)
                    .padding()
                NavigationLink(destination: Login(), isActive: $isActive){
                    Button(action:{
                        self.isActive = true
                    }, label: {
                        Text("Giriş")
                            .foregroundColor(.blue)
                            .padding()
                                                
                    })
                }
          })
               
       }).padding()
    }
}

struct SignUp_Previews: PreviewProvider {
    static var previews: some View {
        SignUp()
    }
}
