//
//  Lists.swift
//  ElininAltindaMobileFinal
//
//  Created by Beyza Erol on 3.01.2022.
//  Copyright © 2022 Beyza Erol. All rights reserved.
//

import SwiftUI

struct Lists: View {
    @State var userid : Int64 = 0
    @State var search = ""
    @State var listModel: [ListModel] = []
    
    var body: some View {
               ZStack{
                   ScrollView(.vertical , showsIndicators: false){
                       VStack(spacing: 15){
                         HStack{
                            Image("search")
                                .resizable()
                                .frame(width: 25 , height: 25)
                                           
                            TextField("Ara", text: $search)
                                .accentColor(Color.blue)
                        }
                        .padding(4)
                        .background(Color.white)
                        .overlay(
                            Capsule(style: .continuous)
                            .stroke(Color.blue , lineWidth: 1)
                        )
                        .padding(.horizontal)
                        .padding(.top,10)
                        
                        VStack {
                            
                           
                            ForEach((self.listModel).filter({$0.name.contains(search) || search.isEmpty})){ model in
                                NavigationLink(destination: ListInfo(userID: self.userid, listName: model.name), label: {
                                    VStack{
                                        HStack{
                                            Text(model.name)
                                            .foregroundColor(.black)
                                            
                                            Spacer()
                                            Image("go")
                                                .resizable()
                                                .frame(width: 10 , height: 10)
                                        }
                                    }
                                    .padding(.horizontal)
                                    .frame(width: 300,height: 50, alignment: .leading)
                                    .background(Rectangle().stroke(Color.blue,lineWidth: 1))
                                    
                                    
                                })
                            }
                        }.padding()
                        
                        
                
                        
                            CreateList(userId: self.userid)
                       }
                   }
                   
                   HStack{
                       if userid == 0{
                           BottomNavbarItem(image: Image("home"))
                           BottomNavbarItem(image: Image("category"))
                           BottomNavbarItem(image: Image("love"))
                           BottomNavbarItem(image: Image("cart"))
                           BottomNavbarItem(image: Image("list"))
                       }
                       else{
                           BottomNavbarHome(userId: self.userid, image: Image("home"))
                            BottomNavbarCategory(image: Image("category"))
                           BottomNavbarFavorites(userId: self.userid ,image: Image("love"))
                           BottomNavbarCart(userId: self.userid,image: Image("cart"))
                           BottomNavbarHelp(userId: self.userid ,image: Image("list"))
                       }
                           
                   }
                   .padding()
                   .background(Color.white)
                   .clipShape(Capsule())
                   .padding(.horizontal)
                   .shadow(color: Color.black.opacity(0.15), radius: 8, x: 2, y: 6)
                   .frame( maxHeight: .infinity, alignment: .bottom)
           }
           
        .onAppear(perform: {
               self.listModel = DB_Manager.sharedInstance.getLists(userid: self.userid)
                
            
            })
        .navigationBarTitle("Listelerim", displayMode: .inline)
        .navigationBarBackButtonHidden(true)
        
    }
}

struct Lists_Previews: PreviewProvider {
    static var previews: some View {
        Lists(userid: Int64())
    }
}


struct CreateList: View {
    @State private var name:String = ""
    @State var userId : Int64 = 0
    @State var flag : Bool =  true
    @State var isActive : Bool =  false
    @State var flag2 : Int64 = 0
    var body: some View {
        VStack(spacing : 10){
            Text("Yeni Bir Liste Oluştur")
                .padding()
            TextField("Liste Adı", text: $name)
                .keyboardType(.alphabet)
                .padding(.all)
                .frame(width: 250,height: 40 , alignment: .center)
                .border(Color.black , width: 1)
            
              NavigationLink(destination: Lists(userid: self.userId), isActive:  self.$isActive){
                Button(action:{
                    self.flag = DB_Manager.sharedInstance.isContainName(userId: self.userId, listName: self.name)
                    if self.flag == false{
                        DB_Manager.sharedInstance.createList(userId: self.userId, listName: self.name)
                                   
                        self.isActive = true
                    }
                    else{
                        self.flag2 = 1
                    }
                }, label: {
                        Text("Liste Oluştur")
                            .bold()
                            .frame(width: 200,height: 50 , alignment: .center)
                            .foregroundColor(.white)
                            .background(Color.blue)
                            .cornerRadius(10)
                            .padding()
                                                           
            })
        }
            
            if self.flag2 != 0 {
                Text("Bu isimde liste mevcuttur")
                    .foregroundColor(Color.red)
            }
        
        }
       .frame( maxWidth: .infinity,maxHeight: .infinity)
        .padding(.top,20)
        .padding(.bottom,20)
        .padding(5)
        
        .background(RoundedRectangle(cornerRadius: 20).stroke(Color.black,lineWidth: 1))
        .padding(.all, 40)
        
        
    }
    
}




