//
//  MyFavorites.swift
//  ElininAltindaMobileFinal
//
//  Created by Beyza Erol on 3.01.2022.
//  Copyright © 2022 Beyza Erol. All rights reserved.
//

import SwiftUI

struct MyFavorites: View {
    @State var userid : Int64 = 0
    var body: some View {
        ZStack{
            ScrollView(.vertical , showsIndicators: false){
                VStack(spacing : 10){
                    FavoriteSearchView()
                    FavoriteProdeuctView(userid: self.userid)
                }
            }
            HStack{
                if userid == 0{
                    BottomNavbarItem(image: Image("home"))
                    BottomNavbarItem(image: Image("category"))
                    BottomNavbarItem(image: Image("love"))
                    BottomNavbarItem(image: Image("cart"))
                    BottomNavbarItem(image: Image("list"))
                }
                else{
                    BottomNavbarHome(userId: self.userid, image: Image("home"))
                    BottomNavbarCategory(image: Image("category"))
                    BottomNavbarFavorites(userId: self.userid ,image: Image("love"))
                    BottomNavbarCart(userId: self.userid,image: Image("cart"))
                    BottomNavbarHelp(userId: self.userid,image: Image("list"))
                }
                                   
            }
            .padding()
            .background(Color.white)
            .clipShape(Capsule())
            .padding(.horizontal)
            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 2, y: 6)
            .frame( maxHeight: .infinity, alignment: .bottom)
        }
        .navigationBarTitle("Favorilerim", displayMode: .inline)
        .navigationBarBackButtonHidden(true)
    
    }
}

struct MyFavorites_Previews: PreviewProvider {
    static var previews: some View {
        MyFavorites(userid: Int64())
    }
}

struct FavoriteSearchView: View {
      @State private var search:String = ""
    var body: some View {
        HStack{
            Image("search")
                .resizable()
                .frame(width: 20 , height: 20)
                .padding(.trailing,8)
            TextField("Ara", text: $search)
        }
        .padding(4)
        .background(Color.white)
        .overlay(
            Capsule(style: .continuous)
                .stroke(Color.blue , lineWidth: 1)
        )
        .padding(.horizontal)
        
    }
}

struct FavoriteProdeuctView: View {
    @State var userid : Int64 = 0
    @State var isActive : Bool = false
    @State var isActive2 : Bool = false
    @State var flag : Int64 = 0
    @State var productModels: [ProductModel] = []
    var body: some View {
    
        VStack {
            ForEach(self.productModels){ (model) in
                NavigationLink(destination: ProductInfo(item: model, userID: self.userid), label: {
                    VStack{
                        HStack{
                            Image("logo4")
                                .resizable()
                                .frame(width: 40,height: 40, alignment: .leading)
                                .foregroundColor(Color.white)
                                .padding(.horizontal)
                            VStack{
                                HStack{
                                    Text("Ürün Adı:")
                                    Text(model.name)
                                }
                               
                                HStack{
                                    Text(model.info)
                                }
                            }
                             .foregroundColor(.white)
                            .frame( maxWidth: .infinity,maxHeight: .infinity , alignment: .leading)
                        }
                        HStack(spacing : 5){
                            
                            NavigationLink(destination: MyCart(userid: self.userid), isActive:  self.$isActive2){
                                Button(action:{
                                    
                                    // if ürün stokta varsa
                                    if DB_Manager.sharedInstance.isStockEnough(productId: model.id) > 0{
                                            DB_Manager.sharedInstance.AddCart(userId: self.userid, productId: model.id)
                                        self.isActive2 = true
                                        
                                    }
                                    else{
                                        self.flag = 1
                                    }
                                   
                                }, label: {
                                        Text("Sepete Ekle")
                                            //.padding(5)
                                            .foregroundColor(.white)
                                            .background(Rectangle().stroke(Color.white,lineWidth: 1))
                                            .frame(width: 100, height: 25, alignment: .bottom)
                                })
                            }
                            
                            Text("\(model.price)TL")
                                .padding(.horizontal)
                                .foregroundColor(.white)
                                .background(Rectangle().stroke(Color.white,lineWidth: 1))
                                .frame(width: 100, height: 25, alignment: .bottom)
                            }
                        }
                        .padding()
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                    .frame( maxWidth: .infinity,maxHeight: .infinity, alignment: .trailing)
                })
                if self.isActive2 == false && self.flag == 1{
                    Text("Ürün Tükenmiştir")
                        .foregroundColor(Color.red)
                }
            }
        }.padding()
        
        .onAppear(perform: {
            self.productModels = DB_Manager.sharedInstance.getFavorites(userid: self.userid)
        })
          //.navigationBarBackButtonHidden(true)
    }
}




