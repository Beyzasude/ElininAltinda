//
//  DB_Manager.swift
//  ElininAltindaMobileFinal
//
//  Created by Beyza Erol on 3.01.2022.
//  Copyright © 2022 Beyza Erol. All rights reserved.
//

import Foundation
import SQLite
 
class DB_Manager {
   static var sharedInstance=DB_Manager()
    var db: Connection?
       
       let User = Table("User")
       let User_id = Expression<Int64>("User_id")
       let Name = Expression<String>("Name")
       let Surname = Expression<String>("Surname")
       let Email = Expression<String>("Email")
       let Password = Expression<String>("Password")
       
       
       let Product = Table("Product")
       let Product_id = Expression<Int64>("Product_id")
       let Product_name = Expression<String>("Product_name")
       let Product_price = Expression<Int64>("Product_price")
       let Product_rating = Expression<Int64>("Product_rating")
       let Product_stock = Expression<Int64>("Product_stock")
       let Product_info = Expression<String>("Product_info")
       let Product_details = Expression<String>("Product_details")
       
       let Favorites = Table("Favorites")
       let FavoritesId = Expression<Int64>("FavoritesId")
       let UserId = Expression<Int64>("UserId")
       let ProductId = Expression<Int64>("ProductId")
    
       let Cart = Table("Cart")
       let CartId = Expression<Int64>("CartId")
       let UserCartId = Expression<Int64>("UserCartId")
       let ProductCartId = Expression<Int64>("ProductCartId")
    
        let ListCategory = Table("ListCategory")
        let ListCategoryId = Expression<Int64>("ListCategoryId")
        let ListCategoryUserId = Expression<Int64>("ListCategoryUserId")
        let ListCategoryName = Expression<String>("ListCategoryName")
        
    
        let Lists = Table("Lists")
        let ListId = Expression<Int64>("ListId")
        let ListUserId = Expression<Int64>("ListUserId")
        let ListProductId = Expression<Int64>("ListProductId")
        let ListsNames = Expression<String>("ListsNames")
    
       init(){
           let path=NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
           print(path)
           
           do{
               db = try Connection("\(path)/Db_ElininAltinda.sqlite3")
             
               
               try db!.run(User.create(temporary: false, ifNotExists: true, block: {
                   t in
                   t.column(User_id, primaryKey: .autoincrement)
                   t.column(Name)
                   t.column(Surname)
                   t.column(Email,unique: true)
                   t.column(Password)
                   
               }))
               
               try db!.run(Product.create(temporary: false, ifNotExists: true, block: {
                   t in
                   t.column(Product_id, primaryKey: .autoincrement)
                   t.column(Product_name)
                   t.column(Product_price)
                   t.column(Product_rating)
                   t.column(Product_stock)
                   t.column(Product_info)
                   t.column(Product_details)
                   
               }))
               
                try db!.run(Favorites.create(temporary: false, ifNotExists: true, block: {
                    t in
                    t.column(FavoritesId, primaryKey: .autoincrement)
                    t.column(UserId)
                    t.column(ProductId)
                    t.foreignKey(UserId, references: User,User_id ,delete: .setNull)
                    t.foreignKey(ProductId, references:Product,Product_id ,delete: .setNull)
               }))
               
               
            try db!.run(Cart.create(temporary: false, ifNotExists: true, block: {
                 t in
                 t.column(CartId, primaryKey: .autoincrement)
                 t.column(UserCartId)
                 t.column(ProductCartId)
                 t.foreignKey(UserCartId, references: User,User_id ,delete: .setNull)
                 t.foreignKey(ProductCartId, references:Product,Product_id ,delete: .setNull)
            }))
            
               try db!.run(ListCategory.create(temporary: false, ifNotExists: true, block: {
                    t in
                    t.column(ListCategoryId, primaryKey: .autoincrement)
                    t.column(ListCategoryUserId)
                    t.column(ListCategoryName)
            }))
            
             try db!.run(Lists.create(temporary: false, ifNotExists: true, block: {
                    t in
                    t.column(ListId, primaryKey: .autoincrement)
                    t.column(ListProductId)
                    t.column(ListUserId)
                    t.column(ListsNames)
                
             }))
            
           }
           catch{
               print("HATA \(error)")
           }
       }
    
    public func addUser(nameValue: String, surnameValue: String, emailValue: String, passwordValue: String) {
        do {
            try db!.run(User.insert(Name <- nameValue, Surname <- surnameValue, Email <- emailValue, Password <- passwordValue))
        } catch {
            print(error.localizedDescription)
        }
    }
    
    public func addProduct(nameValue: String, PriceValue: Int64, stockValue: Int64, ratingValue: Int64 , infoValue: String, detailValue: String) {
        do {
            try db!.run(Product.insert(Product_name <- nameValue, Product_price <- PriceValue, Product_rating <- ratingValue, Product_stock <- stockValue, Product_info <- infoValue, Product_details <- detailValue ))
        } catch {
            print(error.localizedDescription)
        }
    }
    
    public func getProducts() -> [ProductModel] {
     
        var productModels: [ProductModel] = []
     
        do {
     
            // loop through all users
            for product in try db!.prepare(Product) {
     
                // create new model in each loop iteration
                let productModel: ProductModel = ProductModel()
     
                // set values in model from database
                productModel.id = product[Product_id]
                productModel.name = product[Product_name]
                productModel.price = product[Product_price]
                productModel.stock = product[Product_stock]
                productModel.rating = product[Product_rating]
                productModel.info = product[Product_info]
                productModel.details = product[Product_details]
     
                // append in new array
                productModels.append(productModel)
            }
        } catch {
            print(error.localizedDescription)
        }
     
        // return array
        return productModels
    }

    func loginAuthentication(email:String , password:String) -> Int64 {
        for user in try! db!.prepare(User){
          
            if user[Email] == email && user[Password] == password{
                return user[User_id]
            }
        }
        return 0
    }
    
    
    func AddFavorite(userId : Int64 , productId : Int64){
        
         do {
            try db!.run(Favorites.insert(UserId <- userId ,ProductId <- productId))
        } catch {
            print(error.localizedDescription)
            }
    }
    
    func DeleteFavorites ( userId : Int64, productId : Int64){
        do{
            let favorite : Table = Favorites.filter(ProductId == productId && UserId == userId)
            try db!.run(favorite.delete())
        }
        catch{
            print(error.localizedDescription)
        }
    }
    
    func IsFavorite (userId : Int64,productId : Int64) -> Bool{
       for favorite in try! db!.prepare(Favorites){
          
            if favorite[ProductId] == productId && favorite[UserId] == userId {
                return true
            }
        }
        return false
    }
    
    func getFavorites(userid : Int64) -> [ProductModel] {
        
        var productModels: [ProductModel] = []
        var favProducts: [Int64] = []
        do {
            for favorite in try! db!.prepare(Favorites){
                if favorite[UserId] == userid{
                    favProducts.append(favorite[ProductId])
                }
            }
            for product in try! db!.prepare(Product){
                if favProducts.contains(product[Product_id]){
                        let productModel: ProductModel = ProductModel()
                        // set values in model from database
                        productModel.id = product[Product_id]
                        productModel.name = product[Product_name]
                        productModel.price = product[Product_price]
                        productModel.stock = product[Product_stock]
                        productModel.rating = product[Product_rating]
                        productModel.info = product[Product_info]
                        productModel.details = product[Product_details]
                        
                        // append in new array
                        productModels.append(productModel)
                    
                }
            }
            
        }
           return productModels
    }
    
    func isStockEnough(productId : Int64) -> Int64{
        
        for product in try! db!.prepare(Product){
        
            if product[Product_id] == productId  {
                return product[Product_stock]
            }
        }
        return 0
    }
    
    
    func AddCart(userId : Int64 , productId : Int64){
         do {
            try db!.run(Cart.insert(UserCartId <- userId ,ProductCartId <- productId))
            
            for product in try! db!.prepare(Product){
              
                if product[Product_id] == productId  {
                    
                    try db!.run(Product.update(Product_stock <- (Product_stock-1)))
                }
            }
        } catch {
            print(error.localizedDescription)
            }
    }
    
    
    func DeleteCart( userId : Int64, productId : Int64){
        var  cartid : Int64 = 0
        do{
            
            for cart in try! db!.prepare(Cart){
                if cart[UserCartId] == userId{
                    cartid = cart[CartId]
                }
            }
            
            let cart : Table = Cart.filter(ProductCartId == productId && UserCartId == userId && CartId == cartid)
            try db!.run(cart.delete())
        }
        catch{
            print(error.localizedDescription)
        }
    }
    
    //üründen kaç tane varsa hepsini siler
    func DeleteProductCart( userId : Int64, productId : Int64){
        do{
            let cart : Table = Cart.filter(ProductCartId == productId && UserCartId == userId)
            try db!.run(cart.delete())
        }
        catch{
            print(error.localizedDescription)
        }
    }
    
    
    
    func ProductCountCart(userId : Int64) -> Int64{
        var count : Int64 = 0
        for cart in try! db!.prepare(Cart){
            if cart[UserCartId] == userId{
                count = count + 1
            }
        }
        return count
    }
    
    
    func ProductFreq(userId: Int64, productId : Int64) -> Int64{
         var cartProducts: [Int64] = []
               
            for cart in try! db!.prepare(Cart){
                if cart[UserCartId] == userId{
                    cartProducts.append(cart[ProductCartId])
                }
            }
               
               
            for cart in try! db!.prepare(Cart){
                if cartProducts.contains(cart[ProductCartId]){
                    let flag = try! db!.scalar(Cart.filter(ProductCartId == productId && UserCartId == userId).count)
                    return Int64(Int(flag))
                       
                }
                   
        }
        return 0
    }
 
    
    func TotalPrice(userId : Int64) -> Int64{
        var totalPrice : Int64 = 0
      
        var cartProducts: [Int64] = []
        
        for cart in try! db!.prepare(Cart){
            if cart[UserCartId] == userId{
                cartProducts.append(cart[ProductCartId])
            }
        }
        
        
        for product in try! db!.prepare(Product){
            if cartProducts.contains(product[Product_id]){
                let flag = try! db!.scalar(Cart.filter(ProductCartId == product[Product_id] && UserCartId == userId).count)
                totalPrice = totalPrice + product[Product_price] * Int64(Int(flag))
                
            }
                
            
        }
        
        /*for product in try! db!.prepare(Product){
            if cartProducts.contains(product[Product_id]){
                totalPrice = totalPrice + product[Product_price]
            }
        }*/
        return totalPrice
        
    }
    
    
    func getCartProducts(userid : Int64) -> [ProductModel] {
        
        var productModels: [ProductModel] = []
        var cartProducts: [Int64] = []
        do {
            for cart in try! db!.prepare(Cart){
                if cart[UserCartId] == userid{
                    cartProducts.append(cart[ProductCartId])
                }
            }
            for product in try! db!.prepare(Product){
                if cartProducts.contains(product[Product_id]){
                        let productModel: ProductModel = ProductModel()
                        // set values in model from database
                        productModel.id = product[Product_id]
                        productModel.name = product[Product_name]
                        productModel.price = product[Product_price]
                        productModel.stock = product[Product_stock]
                        productModel.rating = product[Product_rating]
                        productModel.info = product[Product_info]
                        productModel.details = product[Product_details]
                        
                        // append in new array
                        productModels.append(productModel)
                    
                }
            }
            
        }
           return productModels
    }
    
    
    func createList(userId:Int64 , listName : String){
           
            do {
               try db!.run(ListCategory.insert(ListCategoryUserId <- userId ,ListCategoryName <- listName))
           } catch {
               print(error.localizedDescription)
               }
       }
    
    
     func getLists(userid : Int64) -> [ListModel] {
         
         var listModels: [ListModel] = []
         //var categoryName: [String] = []
         do {
             for liste in try! db!.prepare(ListCategory){
                 if liste[ListCategoryUserId] == userid{
                  let listModel: ListModel = ListModel()
                  // set values in model from database
                  listModel.id = liste[ListCategoryId]
                  listModel.name = liste[ListCategoryName]
                  listModels.append(listModel)
                 }
             }
             
             
         }
            return listModels
     }
    
    func AddToList(userId : Int64 , productId : Int64 , listName : String){
        
         do {
            try db!.run(Lists.insert(ListUserId <- userId ,ListProductId <- productId , ListsNames <- listName))
        } catch {
            print(error.localizedDescription)
        }
    }
    
    
    func getListsProduct(userid : Int64, listName: String) -> [ProductModel] {
        
        var productModels: [ProductModel] = []
        var listProducts: [Int64] = []
        do {
            for list in try! db!.prepare(Lists){
                if list[ListUserId] == userid && list[ListsNames] == listName{
                    listProducts.append(list[ListProductId])
                }
            }
            for product in try! db!.prepare(Product){
                if listProducts.contains(product[Product_id]){
                        let productModel: ProductModel = ProductModel()
                        // set values in model from database
                        productModel.id = product[Product_id]
                        productModel.name = product[Product_name]
                        productModel.price = product[Product_price]
                        productModel.stock = product[Product_stock]
                        productModel.rating = product[Product_rating]
                        productModel.info = product[Product_info]
                        productModel.details = product[Product_details]
                        
                        // append in new array
                        productModels.append(productModel)
                    
                }
            }
            
        }
           return productModels
    }
    
    func isContainName(userId : Int64 , listName : String) -> Bool{
        
        for list in try! db!.prepare(ListCategory){
        
            if list[ListCategoryUserId] == userId && list[ListCategoryName] == listName {
                return true
            }
        }
        return false
    }
}
