//
//  ContentView.swift
//  ElininAltindaMobileFinal
//
//  Created by Beyza Erol on 3.01.2022.
//  Copyright © 2022 Beyza Erol. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var userid : Int64 = 0
    var body: some View {
        NavigationView{
            Home(userid: userid)
            //AddProduct()
        }
       
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



