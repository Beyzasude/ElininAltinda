//
//  ProductModel.swift
//  ElininAltindaMobileFinal
//
//  Created by Beyza Erol on 3.01.2022.
//  Copyright © 2022 Beyza Erol. All rights reserved.
//

import Foundation
class ProductModel: Identifiable {
    public var id : Int64 = 0
    public var name: String = ""
    public var price: Int64 = 0
    public var rating: Int64 = 0
    public var stock: Int64 = 0
    public var info: String = ""
    public var details: String = ""
    
}
