//
//  UserModel.swift
//  ElininAltindaMobileFinal
//
//  Created by Beyza Erol on 3.01.2022.
//  Copyright © 2022 Beyza Erol. All rights reserved.
//

import Foundation
class UserModel: Identifiable {
    public var id: Int64 = 0
    public var name: String = ""
    public var email: String = ""
    public var password: String = ""
}
