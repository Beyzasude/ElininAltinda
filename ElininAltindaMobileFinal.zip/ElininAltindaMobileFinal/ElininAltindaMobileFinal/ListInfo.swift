//
//  ListInfo.swift
//  ElininAltindaMobileFinal
//
//  Created by Beyza Erol on 3.01.2022.
//  Copyright © 2022 Beyza Erol. All rights reserved.
//

import SwiftUI

struct ListInfo: View {
    @State var userID : Int64 = 0
    @State var listName : String = ""
    var body: some View {
        ZStack{
            ScrollView(){
                VStack(spacing:10){
                    SearchView()
                    ListsProductView(userid: self.userID, listName: self.listName)
                }
            }
        }
        .navigationBarTitle("\(self.listName)", displayMode: .inline)
    
    }
}

struct ListInfo_Previews: PreviewProvider {
    static var previews: some View {
        ListInfo(userID: Int64(), listName: String())
    }
}


struct ListsProductView: View {
    @State var userid : Int64 = 0
    @State var listName : String = ""
     @State var isActive2 : Bool = false
    @State var productModels: [ProductModel] = []
    var body: some View {
    
        VStack {
            ForEach(self.productModels){ (model) in
                NavigationLink(destination: ProductInfo(item: model, userID: self.userid), label: {
                    VStack{
                        HStack{
                            Image("logo4")
                                .resizable()
                                .frame(width: 40,height: 40, alignment: .leading)
                                .foregroundColor(Color.white)
                                .padding(.horizontal)
                            VStack{
                                HStack{
                                    Text("Ürün Adı:")
                                    Text(model.name)
                                }
                               
                                HStack{
                                    Text(model.info)
                                }
                            }
                             .foregroundColor(.white)
                            .frame( maxWidth: .infinity,maxHeight: .infinity , alignment: .leading)
                        }
                        HStack(spacing : 5){
                            
                            NavigationLink(destination: MyCart(userid: self.userid), isActive:  self.$isActive2){
                                Button(action:{
                                    
                                    DB_Manager.sharedInstance.AddCart(userId: self.userid, productId: model.id )
                                    
                                    self.isActive2 = true
                                    
                                }, label: {
                                        Text("Sepete Ekle")
                                            //.padding(5)
                                            .foregroundColor(.white)
                                            .background(Rectangle().stroke(Color.white,lineWidth: 1))
                                            .frame(width: 100, height: 25, alignment: .bottom)
                                })
                            }
                            
                            Text("\(model.price)TL")
                                .padding(.horizontal)
                                .foregroundColor(.white)
                                .background(Rectangle().stroke(Color.white,lineWidth: 1))
                                .frame(width: 100, height: 25, alignment: .bottom)
                            }
                        }
                        .padding()
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                    .frame( maxWidth: .infinity,maxHeight: .infinity, alignment: .trailing)
                })
                
            }
        }.padding()
        
        .onAppear(perform: {
            self.productModels = DB_Manager.sharedInstance.getListsProduct(userid: self.userid, listName: self.listName )
        })
          
    }
}
