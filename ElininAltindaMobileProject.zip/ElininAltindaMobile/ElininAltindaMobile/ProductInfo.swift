//
//  ProductInfo.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 4.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import SwiftUI

struct ProductInfo: View {
    let item : ProductModel
    @State var flag : Int64 = 0
    @State var userID : Int64 = 0
    @State var isFavorite : Bool = false
    @State var isFavorite2 : Bool = false
    @State var isActive : Bool = false
    @State var isActive2 : Bool = false
    var body: some View {
        NavigationView{
        VStack{
            
            HStack{
                Spacer()
                NavigationLink(destination: Login() ,isActive: $isActive ){
                Button(action: {
                    if self.userID == 0{
                        self.isActive = true
                    }
                    else{
                        self.flag = self.flag + 1
                        self.isFavorite2 =  DB_Manager.sharedInstance.IsFavorite(userId:self.userID,productId: self.item.id)
                        self.isFavorite = self.isFavorite2
                            
                        if self.isFavorite2 == false {
                            DB_Manager.sharedInstance.AddFavorite(userId:self.userID,productId: self.item.id)
                            self.isFavorite = true
                        }
                            
                        if self.isFavorite2 == true {
                            DB_Manager.sharedInstance.DeleteFavorites(userId:self.userID, productId: self.item.id)
                                self.isFavorite = false
                        }
                        
                    }
                    
                }, label: {
                    if DB_Manager.sharedInstance.IsFavorite(userId: self.userID,productId: self.item.id) == true && flag == 0{
                         Image("redheart")
                            .resizable()
                            .frame(width: 35, height: 35,alignment: .top)
                    }
                        
                    else if self.isFavorite == true && flag != 0 {
                             Image("redheart")
                                .resizable()
                                .frame(width: 35, height: 35,alignment: .top)
                    }
                        
                        
                    else{
                         Image("emptyheart")
                            .resizable()
                            .frame(width: 35, height: 35,alignment: .top)
                    }
 
                })
            }
            }
            VStack{
                
                 Image("logoDetail")
                    .resizable()
                    .frame(width: 200, height: 200, alignment: .center)
                    .padding(.top,-200)
                    Text(item.name)
                    Text(item.info)
                
            }
           
            
            HStack(spacing:4){
                ForEach(0 ..< 5){ item in
                    Image("star")
                    .resizable()
                        .frame(width: 15, height: 15)
                }
                Text("| 8 Değerlendirme")
            }
            Text("Satıcı: Elinin Altında")
                .padding(.trailing,185)
                .padding(.top)
                
            HStack{
                Image("car")
                    .resizable()
                    .frame(width: 30, height: 25)
                Text("Tahmini kargoya Teslim: 10 gün içinde")
            }
            VStack{
                Text("Ürün Detaylı Açıklaması:")
                    .bold()
                    .padding(.trailing,100)
                    .padding(.top,10)
                Text(item.details)
                    .padding(.trailing,145)
                    .padding()
                
            }
            .background(Capsule().stroke(Color.black,lineWidth: 1))
            
            
            HStack{
                Text("\(item.price) TL")
                    .frame(width: 100,height: 40 , alignment: .center)
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(2)
                    .padding()
                
                
                if self.userID != 0{
                    NavigationLink(destination: MyCart(userid: self.userID), isActive:  $isActive2){
                        Button(action:{
                            
                            DB_Manager.sharedInstance.AddCart(userId: self.userID, productId: self.item.id)
                            
                                self.isActive2 = true
                            
                        }, label: {
                        Text("Sepete Ekle")
                        .frame(width: 180,height: 40 , alignment: .center)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(2)
                        .padding()
                            
                    })
                }
            }
            else{
                NavigationLink(destination: Login(), isActive:  $isActive2){
                        Button(action:{
                            self.isActive2 = true
                            
                        }, label: {
                        Text("Sepete Ekle")
                        .frame(width: 180,height: 40 , alignment: .center)
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(2)
                        .padding()
                            
                    })
                }
            }
        }
    }
}
    //.navigationBarHidden(true)
        .navigationBarBackButtonHidden(false)
    }
}

struct ProductInfo_Previews: PreviewProvider {
    static var previews: some View {
        ProductInfo(item: ProductModel(), userID: Int64())
    }
}











/*
struct ProductInfo: View {
    let item : ProductModel
    @State var flag : Int64 = 0
    @State var userID : Int64 = 0
    @State var isFavorite : Bool = false
    @State var isFavorite2 : Bool = false
    @State var isActive : Bool = false
    @State var isActive2 : Bool = false
    var body: some View {
        NavigationView{
        VStack{
            
            HStack{
                Spacer()
                NavigationLink(destination: Login() ,isActive: $isActive ){
                Button(action: {
                    if self.userID == 0{
                        self.isActive = true
                    }
                    else{
                        self.flag = self.flag + 1
                        self.isFavorite2 =  DB_Manager.sharedInstance.IsFavorite(userId:self.userID,productId: self.item.id)
                        self.isFavorite = self.isFavorite2
                            
                        if self.isFavorite2 == false {
                            DB_Manager.sharedInstance.AddFavorite(userId:self.userID,productId: self.item.id)
                            self.isFavorite = true
                        }
                            
                        if self.isFavorite2 == true {
                            DB_Manager.sharedInstance.DeleteFavorites(userId:self.userID, productId: self.item.id)
                                self.isFavorite = false
                        }
                        
                    }
                    
                }, label: {
                    if DB_Manager.sharedInstance.IsFavorite(userId: self.userID,productId: self.item.id) == true && flag == 0{
                         Image("redheart")
                            .resizable()
                            .frame(width: 35, height: 35,alignment: .top)
                    }
                        
                    else if self.isFavorite == true && flag != 0 {
                             Image("redheart")
                                .resizable()
                                .frame(width: 35, height: 35,alignment: .top)
                    }
                        
                        
                    else{
                         Image("emptyheart")
                            .resizable()
                            .frame(width: 35, height: 35,alignment: .top)
                    }
 
                })
            }
            }
            VStack{
                
                 Image("logoDetail")
                    .resizable()
                    .frame(width: 200, height: 200, alignment: .center)
                    .padding(.top,-200)
                    Text(item.name)
                    Text(item.info)
                
            }
           
            
            HStack(spacing:4){
                ForEach(0 ..< 5){ item in
                    Image("star")
                    .resizable()
                        .frame(width: 15, height: 15)
                }
                Text("| 8 Değerlendirme")
            }
            Text("Satıcı: Elinin Altında")
                .padding(.trailing,185)
                .padding(.top)
                
            HStack{
                Image("car")
                    .resizable()
                    .frame(width: 30, height: 25)
                Text("Tahmini kargoya Teslim: 10 gün içinde")
            }
            VStack{
                Text("Ürün Detaylı Açıklaması:")
                    .bold()
                    .padding(.trailing,100)
                    .padding(.top,10)
                Text(item.details)
                    .padding(.trailing,145)
                    .padding()
                
            }
            .background(Capsule().stroke(Color.black,lineWidth: 1))
            
            
            HStack{
                Text("\(item.price) TL")
                    .frame(width: 100,height: 40 , alignment: .center)
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(2)
                    .padding()
                
                NavigationLink(destination: Login(), isActive:  $isActive2){
                    Button(action:{
                        if self.userID != 0{
                        
                            DB_Manager.sharedInstance.AddCart(userId: self.userID, productId: self.item.id)
                        
                        }
                        else{
                            self.isActive2 = true
                        }
                    }, label: {
                    Text("Sepete Ekle")
                    .frame(width: 180,height: 40 , alignment: .center)
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(2)
                    .padding()
                        
                })
            }
                
        }
    }
}
    //.navigationBarHidden(true)
        .navigationBarBackButtonHidden(false)
    }
}

struct ProductInfo_Previews: PreviewProvider {
    static var previews: some View {
        ProductInfo(item: ProductModel(), userID: Int64())
    }
}
 
*/
