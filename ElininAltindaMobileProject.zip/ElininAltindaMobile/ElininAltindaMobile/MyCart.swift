//
//  MyCart.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 6.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import SwiftUI

struct MyCart: View {
     @State var userid : Int64 = 0
    var body: some View {
        ZStack{
            ScrollView{
                VStack(spacing : 50){
                   
                        
                       ProductView(userId: self.userid)
                }
            }
            
              HStack{
                if userid == 0{
                    BottomNavbarItem(image: Image("home"))
                    BottomNavbarItem(image: Image("category"))
                    BottomNavbarItem(image: Image("love"))
                    BottomNavbarItem(image: Image("cart"))
                    BottomNavbarItem(image: Image("help"))
                }
                else{
                    BottomNavbarHome(userId: self.userid, image: Image("home"))
                    BottomNavbarCategory(image: Image("category"))
                    BottomNavbarFavorites(userId: self.userid ,image: Image("love"))
                    BottomNavbarCart(userId: self.userid,image: Image("cart"))
                    BottomNavbarHelp(image: Image("help"))
                }
                                    
            }
            .padding()
            .background(Color.white)
            .clipShape(Capsule())
            .padding(.horizontal)
            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 2, y: 6)
            .frame( maxHeight: .infinity, alignment: .bottom)
        }
        .navigationBarTitle("Sepetim",displayMode: .inline)
        .navigationBarBackButtonHidden(true)
        
    }
}

struct MyCart_Previews: PreviewProvider {
    static var previews: some View {
        MyCart(userid: Int64())
    }
}

   struct ProductView: View {
    @State var userId : Int64 = 0
    @State var totalproduct: Int64 = 0
    @State var totalprice: Int64 = 0
    @State var activePositiveButton : Bool = false
    @State var activeNegativeButton : Bool = false
    @State var activeTrashButton : Bool = false
    @State var productModels: [ProductModel] = []
    var body: some View {
        VStack (spacing : 50){
             if DB_Manager.sharedInstance.ProductCountCart(userId: self.userId) == 0{
                                   
                Text("Sepetinizde ürün bulunmamaktadır")
                    .padding(5)
                    .frame( maxWidth: .infinity,maxHeight: .infinity)
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .padding(.horizontal)
                                   
             }
             else if self.totalproduct != 0{
                Text("Sepetinizde \(self.totalproduct) tane ürün bulunmaktadır")
                    .padding(3)
                    .frame( maxWidth: .infinity,maxHeight: .infinity)
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .padding(.horizontal)
                                   
            }
             else{
                Text("Sepetinizde \(DB_Manager.sharedInstance.ProductCountCart(userId: self.userId)) tane ürün bulunmaktadır")
                .padding(3)
                .frame( maxWidth: .infinity,maxHeight: .infinity)
                .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                .padding(.horizontal)
                
            }
            
            ForEach(self.productModels){ (model) in
                
                NavigationLink(destination: ProductInfo(item: model), label: {
                    VStack{
                        HStack{
                            Spacer()
                            NavigationLink(destination: MyCart(userid: self.userId), isActive: self.$activeTrashButton){
                            Button(action: {
                                DB_Manager.sharedInstance.DeleteProductCart(userId: self.userId, productId: model.id)
                                
                                    self.activeTrashButton = true
                                    }, label: {
                                        Image("trash")
                                            .resizable()
                                            .frame(width: 20, height: 20, alignment: .trailing)
                                            .foregroundColor(Color.white)
                            })
                            }
                        }
                       
                        HStack{
                            Image("logo4")
                                .resizable()
                                .frame(width: 40,height: 40, alignment: .leading)
                                .foregroundColor(Color.white)
                                .padding(.horizontal)
                            VStack{
                                HStack{
                                    Text(model.name)
                                }
                                .foregroundColor(.black)
                                HStack{
                                    Text(model.info)
                                        
                                }
                                .foregroundColor(.black )
                                
                                HStack{
                                    
                                    Button(action: {
                                        
                                        DB_Manager.sharedInstance.DeleteCart(userId: self.userId, productId: model.id)
                                        
                                        self.totalprice =  DB_Manager.sharedInstance.TotalPrice(userId: self.userId)
                                                                             
                                         self.totalproduct = DB_Manager.sharedInstance.ProductCountCart(userId: self.userId)
                                        
                                    }, label: {
                                        Text("-")
                                            .foregroundColor(Color.white)
                                            .bold()
                                            .padding()
                                    })
                                    if self.activeNegativeButton == true{
                                         Text("\(DB_Manager.sharedInstance.ProductFreq(userId: self.userId, productId: model.id) - 1 )")
                                            .foregroundColor(Color.white)
                                            .bold()
                                            .padding()
                                        
                                    }
                                    if self.activePositiveButton == true{
                                        Text("\(DB_Manager.sharedInstance.ProductFreq(userId: self.userId, productId: model.id) + 1 )")
                                        .foregroundColor(Color.white)
                                        .bold()
                                        .padding()
                                        
                                    }
                                    if self.activePositiveButton == false && self.activeNegativeButton == false{
                                        Text("\(DB_Manager.sharedInstance.ProductFreq(userId: self.userId, productId: model.id)  )")
                                        .foregroundColor(Color.white)
                                        .bold()
                                        .padding()
                                    
                                    }
                                    
                                    Button(action: {
                                        
                                        DB_Manager.sharedInstance.AddCart(userId: self.userId, productId: model.id)
                                       
                                        self.totalprice =  DB_Manager.sharedInstance.TotalPrice(userId: self.userId)
                                        
                                        self.totalproduct = DB_Manager.sharedInstance.ProductCountCart(userId: self.userId)
                                        
                                    }, label: {
                                        Text("+")
                                            .foregroundColor(Color.white)
                                            .bold()
                                        .padding()
                                    })
                                }
                            .overlay(
                                Rectangle()
                                    .stroke(Color.black , lineWidth: 1)
                                )
                            }
                        }
                        HStack{
                            Spacer()
                            Text("\(model.price)TL")
                                .padding(.horizontal)
                                .foregroundColor(Color.black)
                                .background(RoundedRectangle(cornerRadius: 10).stroke(Color.black,lineWidth: 1))
                                .frame(width: 100, height: 25, alignment: .bottom)
                            }
                        }
                        .padding()
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                        .frame( maxWidth: .infinity,maxHeight: .infinity)
                })
            }
            
            NavigationLink(destination: Home(userid: self.userId), label: {
                     Text("Alışverişe Devam Et")
                        .foregroundColor(Color.black)
                        .padding(10)
                        .frame( maxWidth: .infinity)
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                })
                
                HStack{
                    VStack{
                        Image("logo4")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(Color.white)
                        Text("Sepetteki Ürüne")
                        Text("Benzer Ürünler")
                        
                    }
                    .frame( maxWidth: .infinity,maxHeight: .infinity)
                    .padding(.top,20)
                    .padding(.bottom,20)
                    .padding(5)
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .padding(.horizontal)
                
                    
                    VStack{
                        Image("logo4")
                            .resizable()
                            .foregroundColor(Color.white)
                            .frame(width: 40, height: 40)
                       Text("Sepetteki Ürüne")
                       Text("Benzer Ürünler")
                        
                    }
                     .frame( maxWidth: .infinity,maxHeight: .infinity)
                    .padding(.top,20)
                    .padding(.bottom,20)
                    .padding(5)
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .padding(.horizontal)
                    
                }
                
            HStack(spacing: 50){
                    VStack{
                        Text("Toplam")
                     
                     if self.totalprice == 0 {
                         Text("\(DB_Manager.sharedInstance.TotalPrice(userId: self.userId)) TL")
                         
                     }
                     else{
                         Text("\(self.totalprice) TL")
                     }
                 }
                    
                    Text("Ödeneme işlemine geç")
                }
                .frame( maxWidth: .infinity,maxHeight: .infinity)
                .padding(10)
                .background(Color.blue)
                .clipShape(RoundedRectangle(cornerRadius: 25.0))
                .padding(.horizontal)
            
            
            
            
            
            
            
           
        }.padding()
            
        .onAppear(perform: {
            self.productModels = DB_Manager.sharedInstance.getCartProducts(userid: self.userId)
        })
        
    }
}






















/*
struct MyCart: View {
     @State var userid : Int64 = 0
    var body: some View {
        ZStack{
            ScrollView{
                VStack(spacing : 50){
                    if DB_Manager.sharedInstance.ProductCountCart(userId: self.userid) == 0{
                        
                        Text("Sepetinizde ürün bulunmamaktadır")
                        .padding(5)
                        .frame( maxWidth: .infinity,maxHeight: .infinity)
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                        
                    }
                    else{
                        Text("Sepetinizde \(DB_Manager.sharedInstance.ProductCountCart(userId: self.userid)) tane ürün bulunmaktadır")
                        .padding(3)
                        .frame( maxWidth: .infinity,maxHeight: .infinity)
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                        
                    }
                        
                       ProductView(userId: self.userid)
                }
            }
            
              HStack{
                if userid == 0{
                    BottomNavbarItem(image: Image("home"))
                    BottomNavbarItem(image: Image("category"))
                    BottomNavbarItem(image: Image("love"))
                    BottomNavbarItem(image: Image("cart"))
                    BottomNavbarItem(image: Image("help"))
                }
                else{
                    BottomNavbarHome(userId: self.userid, image: Image("home"))
                    BottomNavbarCategory(image: Image("category"))
                    BottomNavbarFavorites(userId: self.userid ,image: Image("love"))
                    BottomNavbarCart(userId: self.userid,image: Image("cart"))
                    BottomNavbarHelp(image: Image("help"))
                }
                                    
            }
            .padding()
            .background(Color.white)
            .clipShape(Capsule())
            .padding(.horizontal)
            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 2, y: 6)
            .frame( maxHeight: .infinity, alignment: .bottom)
        }
        .navigationBarTitle("Sepetim",displayMode: .inline)
        .navigationBarBackButtonHidden(true)
        
    }
}

struct MyCart_Previews: PreviewProvider {
    static var previews: some View {
        MyCart(userid: Int64())
    }
}

   struct ProductView: View {
    @State var userId : Int64 = 0
    @State var totalprice: Int64 = 0
    @State var activePositiveButton : Bool = false
    @State var activeNegativeButton : Bool = false
    @State var productModels: [ProductModel] = []
    var body: some View {
        VStack (spacing : 50){
            ForEach(self.productModels){ (model) in
                NavigationLink(destination: ProductInfo(item: model), label: {
                    VStack{
                        HStack{
                            Spacer()
                            Image("trash")
                                .resizable()
                                .frame(width: 20, height: 20, alignment: .trailing)
                                .foregroundColor(Color.white)
                        }
                       
                        HStack{
                            Image("logo4")
                                .resizable()
                                .frame(width: 40,height: 40, alignment: .leading)
                                .foregroundColor(Color.white)
                                .padding(.horizontal)
                            VStack{
                                HStack{
                                    Text(model.name)
                                }
                                .foregroundColor(.black)
                                HStack{
                                    Text(model.info)
                                        
                                }
                                .foregroundColor(.black )
                                
                                HStack{
                                    
                                    Button(action: {
                                        
                                        DB_Manager.sharedInstance.DeleteCart(userId: self.userId, productId: model.id)
                                        
                                        self.totalprice =  DB_Manager.sharedInstance.TotalPrice(userId: self.userId)
                                                                             
                                        
                                      
                                    }, label: {
                                        Text("-")
                                            .foregroundColor(Color.white)
                                            .bold()
                                            .padding()
                                    })
                                    if self.activeNegativeButton == true{
                                         Text("\(DB_Manager.sharedInstance.ProductFreq(userId: self.userId, productId: model.id) - 1 )")
                                            .foregroundColor(Color.white)
                                            .bold()
                                            .padding()
                                        
                                    }
                                    if self.activePositiveButton == true{
                                        Text("\(DB_Manager.sharedInstance.ProductFreq(userId: self.userId, productId: model.id) + 1 )")
                                        .foregroundColor(Color.white)
                                        .bold()
                                        .padding()
                                        
                                    }
                                    if self.activePositiveButton == false && self.activeNegativeButton == false{
                                        Text("\(DB_Manager.sharedInstance.ProductFreq(userId: self.userId, productId: model.id)  )")
                                        .foregroundColor(Color.white)
                                        .bold()
                                        .padding()                                    }
                                    
                                    Button(action: {
                                        
                                        DB_Manager.sharedInstance.AddCart(userId: self.userId, productId: model.id)
                                       
                                        self.totalprice =  DB_Manager.sharedInstance.TotalPrice(userId: self.userId)
                                        
                                    }, label: {
                                        Text("+")
                                            .foregroundColor(Color.white)
                                            .bold()
                                        .padding()
                                    })
                                }
                            .overlay(
                                Rectangle()
                                    .stroke(Color.black , lineWidth: 1)
                                )
                            }
                        }
                        HStack{
                            Spacer()
                            Text("\(model.price)TL")
                                .padding(.horizontal)
                                .foregroundColor(Color.black)
                                .background(RoundedRectangle(cornerRadius: 10).stroke(Color.black,lineWidth: 1))
                                .frame(width: 100, height: 25, alignment: .bottom)
                            }
                        }
                        .padding()
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                        .frame( maxWidth: .infinity,maxHeight: .infinity)
                })
            }
            
            NavigationLink(destination: Home(userid: self.userId), label: {
                     Text("Alışverişe Devam Et")
                        .foregroundColor(Color.black)
                        .padding(10)
                        .frame( maxWidth: .infinity)
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                })
                
                HStack{
                    VStack{
                        Image("logo4")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(Color.white)
                        Text("Sepetteki Ürüne")
                        Text("Benzer Ürünler")
                        
                    }
                    .frame( maxWidth: .infinity,maxHeight: .infinity)
                    .padding(.top,20)
                    .padding(.bottom,20)
                    .padding(5)
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .padding(.horizontal)
                
                    
                    VStack{
                        Image("logo4")
                            .resizable()
                            .foregroundColor(Color.white)
                            .frame(width: 40, height: 40)
                       Text("Sepetteki Ürüne")
                       Text("Benzer Ürünler")
                        
                    }
                     .frame( maxWidth: .infinity,maxHeight: .infinity)
                    .padding(.top,20)
                    .padding(.bottom,20)
                    .padding(5)
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .padding(.horizontal)
                    
                }
                
            HStack(spacing: 50){
                    VStack{
                        Text("Toplam")
                     
                     if self.totalprice == 0 {
                         Text("\(DB_Manager.sharedInstance.TotalPrice(userId: self.userId)) TL")
                         
                     }
                     else{
                         Text("\(self.totalprice) TL")
                     }
                 }
                    
                    Text("Ödeneme işlemine geç")
                }
                .frame( maxWidth: .infinity,maxHeight: .infinity)
                .padding(10)
                .background(Color.blue)
                .clipShape(RoundedRectangle(cornerRadius: 25.0))
                .padding(.horizontal)
            
            
            
            
            
            
            
           
        }.padding()
            
        .onAppear(perform: {
            self.productModels = DB_Manager.sharedInstance.getCartProducts(userid: self.userId)
        })
        
    }
}


*/

















