//
//  ContentView.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 3.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reser



import SwiftUI

struct ContentView: View {
    @State var userid : Int64 = 0
    var body: some View {
        NavigationView{
             Home(userid: userid)
        }
       
    }
}
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
