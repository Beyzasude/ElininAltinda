//
//  CartModel.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 9.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import Foundation
