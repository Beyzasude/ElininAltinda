//
//  UserHomePage.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 5.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import SwiftUI

struct UserHomePage: View {
    @State var userid :Int64 = 0
    @State var isActive : Bool = false
    var body: some View {
           NavigationView{
               VStack{                
                   UserAppBarView()
                      // .padding(.top,-100)
                    UserSearchView()
                      // .padding(.top,-50)
                UserProdeuctView(userid: self.userid)
                
                  HStack{
            
                    NavigationLink(destination: UserHomePage(userid: self.userid),isActive: $isActive ){
                        Button(action: {
                             self.isActive = true
                        }, label: {
                            Image("home")
                            .resizable()
                            .frame(width: 30, height: 30)
                            .frame(maxWidth: .infinity)
                        })
                    }
                    FavoriteBottomNavbarItem(image: Image("category")){}
                    
                    NavigationLink(destination: MyFavorites(userid: self.userid),isActive: $isActive ){
                       Button(action: {
                            self.isActive = true
                       }, label: {
                           Image("love")
                           .resizable()
                           .frame(width: 30, height: 30)
                           .frame(maxWidth: .infinity)
                       })
                    }
                       
                    FavoriteBottomNavbarItem(image: Image("cart")){}
                    FavoriteBottomNavbarItem(image: Image("help")){}
                      
                   }
                   .padding(.horizontal)
                   .shadow(color: Color.black.opacity(0.15), radius: 8, x: 2, y: 6)
                   .frame( maxHeight: .infinity, alignment: .bottom)
           }
       }
    //.navigationBarHidden(true)
    .navigationBarBackButtonHidden(false)
    }
}

struct UserHomePage_Previews: PreviewProvider {
    static var previews: some View {
        UserHomePage(userid: Int64())
    }
}

struct UserAppBarView: View {
    var body: some View {
        HStack{
            NavigationLink(destination: Login(),label: {
                Image("logo3")
                .resizable()
                .frame(width: 35, height: 35)
                .padding()
                .background(Color(.white))
                .cornerRadius(10.0)
                
            })
            Spacer()
            Text("Elinin Altında")
                .padding()
                .foregroundColor(.blue)
                .font(.title)
        }
    }
}


struct UserSearchView: View {
    @State private var search:String = ""
    var body: some View {
        HStack{
            Image("search")
                .resizable()
                .frame(width: 25 , height: 25)
                .padding(.trailing,8)
            TextField("Ara", text: $search)
        }
        //.textFieldStyle(RoundedBorderTextFieldStyle())
        //.foregroundColor(.blue)
        .padding()
        .background(Capsule().stroke(Color.blue,lineWidth: 2))
        .cornerRadius(1.0)
        .padding(.horizontal)
        
    }
}

struct UserProdeuctView: View {
    @State var userid : Int64 = 0
    @State var productModels: [ProductModel] = []
    var body: some View {
        
        VStack {
            ForEach(self.productModels){ (model) in
                NavigationLink(destination: ProductInfo(item: model, userID: self.userid), label: {
                    VStack{
                        HStack{
                            Image("logo2")
                                .resizable()
                                .frame(width: 80,height: 80, alignment: .leading)
                                .padding(.horizontal)
                            VStack{
                                HStack{
                                    Text("Ürün Adı:")
                                    Text(model.name)
                                }
                                .foregroundColor(.white)
                                HStack{
                                    Text("Ürün Bilgisi:")
                                    Text(model.info)
                                }
                                .foregroundColor(.white )
                            }
                        }
                        HStack{
                            Spacer()
                            Text("\(model.price)TL")
                                .padding(.horizontal)
                                .foregroundColor(.white)
                                .background(Rectangle().stroke(Color.white,lineWidth: 1))
                                .frame(width: 100, height: 25, alignment: .bottom)
                            }
                        }
                        .padding()
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 25.0))
                        .padding(.horizontal)
                        .frame( maxWidth: .infinity,maxHeight: .infinity)
                })

            }
        }.padding()
                          
        .onAppear(perform: {
            self.productModels = DB_Manager.sharedInstance.getProducts()
        })
                      
        }
}

struct UserBottomNavbarItem: View {
    let image: Image
    var body: some View {
        Button(action: {
        }, label: {
            image
            .resizable()
            .frame(width: 30, height: 30)
            .frame(maxWidth: .infinity)
        })
    }
    
}







/*struct UserBottomNavbarItem: View {
    @State var isActive : Bool = false
    let function : String = ""
    @State var userid : Int64 = 0
    let image: Image
    var body: some View {
        
        switch function {
        case "home":
            NavigationLink(destination : UserHomePage(userid: self.userid) , isActive: $isActive){
                Button(action: {
                    self.isActive = true
                }, label: {
                    image
                    .resizable()
                    .frame(width: 30, height: 30)
                    .frame(maxWidth: .infinity)
                })
                
            }
        case "love":
            NavigationLink(destination : MyFavorites(userid: self.userid) , isActive: $isActive){
                Button(action: {
                    self.isActive = true
                    }, label: {
                    image
                        .resizable()
                        .frame(width: 30, height: 30)
                        .frame(maxWidth: .infinity)
                })
            }
        default:
            <#code#>
        }
        
        
           
       }
    
}
*/



