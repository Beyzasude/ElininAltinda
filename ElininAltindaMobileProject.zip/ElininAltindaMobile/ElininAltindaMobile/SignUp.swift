//
//  SignUp.swift
//  ElininAltindaMobile
//
//  Created by Beyza Erol on 3.12.2021.
//  Copyright © 2021 Beyza Erol. All rights reserved.
//

import SwiftUI

struct SignUp: View {
    @State private var name:String = ""
    @State private var surname:String = ""
    @State private var email:String = ""
    @State private var password:String = ""
    @State var isActive : Bool = false
    @State var isCheck : Int64 = 0
    @State var isActiveButton : Bool = false
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    
    func checkPassword(_ password: String) -> Bool{
        let passwordLength = password.count
        var containUpperCase = false
        var containLowerCase = false
        var containNumber = false
        
        for charecter in password{
            if "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ".contains(charecter){
                containUpperCase = true
            }
            
             if "abcçdefgğhıijklmnoöprsştuüvyz".contains(charecter){
                containLowerCase = true
            }
            
             if "0123456789".contains(charecter){
                containNumber = true
            }
        }
        
        if passwordLength >= 5 && containNumber == true && containLowerCase == true && containUpperCase == true{
            return true
        }
        return false
    }
    
    
    
    
    var body: some View {
       VStack(alignment: .leading, spacing: 8, content:{
        
        Text("KAYIT OL")
            .font(.title)
        
        VStack(alignment: .leading, spacing: 8, content:{
            Text("Ad")
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.blue)
            TextField("Adınız", text: $name)
                .padding(10)
                .background(Color(.white))
                .cornerRadius(5)
                .keyboardType(.alphabet)
                .disableAutocorrection(true)
        })
        
        VStack(alignment: .leading, spacing: 8, content:{
            Text("Soyad")
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.blue)
            TextField("Soyadınız", text: $surname)
                .padding(10)
                .background(Color(.white))
                .cornerRadius(5)
                .keyboardType(.alphabet)
                .disableAutocorrection(true)
        })
        
       VStack(alignment: .leading, spacing: 8, content:{
             Text("E-Posta")
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.blue)
            TextField("E-posta Adresiniz", text: $email)
                .padding(10)
                .background(Color(.white))
                .cornerRadius(5)
                .keyboardType(.emailAddress)
                .autocapitalization(.none)
                .disableAutocorrection(true)
            
        })
       
        VStack(alignment: .leading, spacing: 8, content:{
             Text("Şifre")
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.blue)
            
            SecureField("Şifreniz", text: $password)
                .padding(10)
                .background(Color(.white))
                .cornerRadius(5)
                .disableAutocorrection(true)
            if password.count >= 1{
                 if checkPassword(password) == false {
                    Text("şifre en az 5 karakter ve en az bir tane büyük, küçük harf ve rakam içermelidir")
                        .foregroundColor(Color.red)
                }
                
            }
           
        })
       
        
        Button(action: {
        // call function to add row in sqlite database
            if self.checkPassword(self.password){
            DB_Manager().addUser(nameValue: self.name, surnameValue: self.surname, emailValue: self.email, passwordValue: self.password)
                
                self.isCheck = 1
                
               // go back to home page
                self.mode.wrappedValue.dismiss()
            }
            else{
                  self.isActiveButton = true
                
            }
            }, label: {
                Text("Devam Et")
                .bold()
                .frame(width: 250,height: 50 , alignment: .center)
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(10)
                .padding()
                
        })
        .frame(maxWidth: .infinity, alignment: .center)
        .padding(.top, 10)
        .padding(.bottom, 10)
        
        if self.isCheck == 0 && self.isActiveButton == true{
            Text("Geçersiz Şifre")
        }
        
        Spacer()
        
          HStack(alignment: .center, spacing: 60, content:{
                Text("Zaten bir hesabınız var mı?")
                    .foregroundColor(.gray)
                    .padding()
                NavigationLink(destination: Login(), isActive: $isActive){
                    Button(action:{
                        self.isActive = true
                    }, label: {
                        Text("Giriş")
                            .foregroundColor(.blue)
                            .padding()
                                                
                    })
                }
          })
               
       }).padding()
    }
}

struct SignUp_Previews: PreviewProvider {
    static var previews: some View {
        SignUp()
    }
}
